var isAnimated = true;

$("ul li").on("click", function(){

  if(isAnimated){

    isAnimated = false;
    var i = $(this).index();

    $("li").removeClass("on");
    $("li").eq(i).addClass("on");

    $("article.upper").removeClass("upper").addClass("lower");
    $("article").eq(i).addClass("upper");

    setTimeout(function(){
      $("article.lower").removeClass("lower");
      isAnimated = true;
    }, 1000);
  }
})